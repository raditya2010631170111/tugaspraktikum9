import 'package:uts/1_onlineshop_model.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
// import 'package:sqflite/sqlite_api.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  static Database? _database; //static late

  final String tableName = 'tableOnlineShop';
  final String columnIdHp = 'idHp';
  final String columnMerek = 'merek';
  final String columnSpesifikasi = 'spesifikasi';
  final String columnHarga = 'harga';
  final String columnPassword = 'password';

  DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;

  Future<Database?> get _db async {
    if (_database != null) {
      return _database;
    }
    _database = await _initializeDb();
    return _database;
  }

  Future<Database?> _initializeDb() async {
    String databasePath = await getDatabasesPath();
    String path = join(databasePath, 'onlineshop_db');

    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  Future<void> _onCreate(Database db, int version) async {
    var phpmyadmin = "CREATE TABLE $tableName($columnIdHp INTEGER PRIMARY KEY, "
        "$columnMerek TEXT,"
        "$columnSpesifikasi TEXT,"
        "$columnHarga TEXT,"
        "$columnPassword TEXT)";
    await db.execute(phpmyadmin);
  }

  Future<int?> saveOnlineShop(OnlineShopModel onlineshop) async {
    var dbClient = await _db;
    return await dbClient!.insert(tableName, onlineshop.toMap());
  }

  Future<List?> getAllOnlineShop() async {
    var dbClient = await _db;
    var result = await dbClient!.query(tableName, columns: [
      columnIdHp,
      columnMerek,
      columnSpesifikasi,
      columnHarga,
      columnPassword
    ]);
    return result.toList();
  }

  Future<int?> updateOnlineShop(OnlineShopModel onlineshop) async {
    var dbClient = await _db;
    return await dbClient!.update(tableName, onlineshop.toMap(),
        where: '$columnIdHp = ?', whereArgs: [onlineshop.idHp]);
  }

  Future<int?> deleteOnlineShop(int idHp) async {
    var dbClient = await _db;
    return await dbClient!
        .delete(tableName, where: '$columnIdHp = ?', whereArgs: [idHp]);
  }
}
